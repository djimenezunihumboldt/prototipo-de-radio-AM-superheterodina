#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║  deploy.sh — Script de despliegue completo                  ║
# ║  Uso: chmod +x deploy.sh && ./deploy.sh                     ║
# ╚══════════════════════════════════════════════════════════════╝

set -euo pipefail

# Colores
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'; BOLD='\033[1m'

log()     { echo -e "${GREEN}[✓]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✗]${NC} $1"; exit 1; }
heading() { echo -e "\n${BOLD}${BLUE}══ $1 ══${NC}\n"; }

heading "PreciosVenezuela — Deployment Script v1.0"
echo "  Fecha: $(date)"
echo "  Host:  $(hostname)"

# ── Verificar prerequisitos ───────────────────────────────────
heading "Verificando prerequisitos"

command -v docker      >/dev/null 2>&1 || error "Docker no está instalado"
command -v docker-compose >/dev/null 2>&1 || error "docker-compose no está instalado"
log "Docker $(docker --version | cut -d' ' -f3 | tr -d ',')"
log "Docker Compose $(docker-compose --version | cut -d' ' -f4 | tr -d ',')"

# ── Variables de entorno ──────────────────────────────────────
heading "Configurando entorno"

if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        warn ".env no encontrado. Copiando .env.example → .env"
        cp .env.example .env
        error "Por favor edita .env con tus valores reales antes de continuar"
    else
        error ".env no encontrado y no hay .env.example"
    fi
fi

# Verificar variables críticas
source .env
[ -z "${DB_PASSWORD:-}" ]          && error "DB_PASSWORD no configurado en .env"
[ -z "${REDIS_PASSWORD:-}" ]       && error "REDIS_PASSWORD no configurado en .env"
[ -z "${JWT_SECRET:-}" ]           && error "JWT_SECRET no configurado en .env"
[ -z "${JWT_REFRESH_SECRET:-}" ]   && error "JWT_REFRESH_SECRET no configurado en .env"
[ ${#JWT_SECRET} -lt 32 ]          && error "JWT_SECRET debe tener al menos 32 caracteres"
log "Variables de entorno validadas"

# ── SSL ───────────────────────────────────────────────────────
heading "Verificando SSL"

SSL_DIR="./nginx/ssl"
mkdir -p "$SSL_DIR"

if [ ! -f "$SSL_DIR/fullchain.pem" ]; then
    warn "Certificados SSL no encontrados. Generando certificados autofirmados para desarrollo..."
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout "$SSL_DIR/privkey.pem" \
        -out    "$SSL_DIR/fullchain.pem" \
        -subj "/C=VE/ST=Caracas/L=Caracas/O=PreciosVenezuela/CN=localhost" \
        2>/dev/null
    warn "⚠  Certificados autofirmados creados. Para producción usa Let's Encrypt:"
    warn "   certbot certonly --webroot -w /var/www/certbot -d preciosvenezuela.com"
else
    log "Certificados SSL encontrados"
fi

# ── Construir imágenes ────────────────────────────────────────
heading "Construyendo imágenes Docker"

log "Construyendo backend..."
docker-compose build --no-cache backend

log "Construyendo scraper..."
docker-compose build --no-cache scraper

# ── Iniciar servicios ─────────────────────────────────────────
heading "Iniciando servicios"

log "Levantando PostgreSQL y Redis..."
docker-compose up -d postgres redis

log "Esperando que la BD esté lista..."
sleep 10
until docker-compose exec -T postgres pg_isready -U "${DB_USER:-preciosve}" >/dev/null 2>&1; do
    echo -n "."
    sleep 2
done
echo ""
log "PostgreSQL listo"

log "Levantando backend..."
docker-compose up -d backend

log "Levantando nginx..."
docker-compose up -d nginx

log "Levantando scraper..."
docker-compose up -d scraper

# ── Verificación final ────────────────────────────────────────
heading "Verificación de salud"

sleep 5

# Verificar backend
if curl -s -o /dev/null -w "%{http_code}" http://localhost/health | grep -q "200"; then
    log "API Backend: ✅ Respondiendo en /health"
else
    warn "API Backend: ⚠  No responde aún (puede tardar 30s en iniciarse)"
fi

# Mostrar estado de contenedores
echo ""
docker-compose ps

heading "Despliegue completado 🚀"
echo "  🌐 Landing page:  http://localhost"
echo "  🔌 API:           http://localhost/api/v1"
echo "  ❤️  Health check:  http://localhost/health"
echo "  📊 pgAdmin (dev): docker-compose --profile dev up pgadmin"
echo ""
echo "  📋 Logs en tiempo real:"
echo "     docker-compose logs -f backend"
echo "     docker-compose logs -f scraper"
echo ""
warn "Para producción, recuerda configurar Let's Encrypt y un firewall."
